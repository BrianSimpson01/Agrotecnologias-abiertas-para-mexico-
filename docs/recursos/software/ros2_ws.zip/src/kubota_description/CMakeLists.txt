# CMakeLists.txt for kubota_description
cmake_minimum_required(VERSION 3.8)
project(kubota_description)

if(CMAKE_COMPILER_IS_GNUCXX OR CMAKE_CXX_COMPILER_ID MATCHES "Clang")
  add_compile_options(-Wall -Wextra -Wpedantic)
endif()

# find dependencies
find_package(ament_cmake REQUIRED)
find_package(ament_cmake_python REQUIRED)
find_package(rviz2 REQUIRED)
find_package(robot_state_publisher REQUIRED)
find_package(xacro REQUIRED)

if(BUILD_TESTING)
  find_package(ament_lint_auto REQUIRED)
  set(ament_cmake_copyright_FOUND TRUE)
  set(ament_cmake_cpplint_FOUND TRUE)
  ament_lint_auto_find_test_dependencies()
endif()

install(
  DIRECTORY urdf launch config
  DESTINATION share/${PROJECT_NAME}
)

# Instalar los nodos de Python
ament_python_install_package(${PROJECT_NAME})

install(PROGRAMS
  kubota_description/goto_point.py
  DESTINATION lib/${PROJECT_NAME}
)

ament_package()